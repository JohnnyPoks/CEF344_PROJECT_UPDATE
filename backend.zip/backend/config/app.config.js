// eslint-disable-next-line no-unused-expressions
require("dotenv").config;

const MONGO_DB_CONFIG = {
   DB: 'mongodb+srv://johnpokam95:nwgljOqEKuUOecKr@portfoliobackend.byhoifu.mongodb.net/?retryWrites=true&w=majority'
       
}

module.exports = {
    MONGO_DB_CONFIG
}